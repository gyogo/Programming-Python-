#2308 박교령
#이 프로젝트의 이름은 'Personal computer Custom'입니다.
#간단히 설명하자면, 각자 컴퓨터를 주문할 때 원하는 부품들을 따로 따로 
# 교체가 가능한 조립주문 프로그램입니다.
#실행파일입니다
from order import Order
o = Order() #Order함수 넣어주기
o.show_kinds() #order클래스에 있는 show_kinds()실행