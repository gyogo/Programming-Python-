class Computer:
    def __init__(self): #사용자가 선택한 부품들을 저장하는 곳
        self.CPU=""
        self.GPU=""
        self.RAM=""
        self.price=0
